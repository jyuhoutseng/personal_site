import time

print("Quiz_2: ")
input("What is the result of the following calculation in Python's interactive mode? 7/2")
time.sleep(.5)
print("3.5")

input("What is the result of the following calculation in Python's interactive mode? 7//2")
time.sleep(.5)
print("3")

input("What is the result of the following calculation in Python's interactive mode? 7%2")
time.sleep(.5)
print("1")

input("What is the result of the following calculation in Python's interactive mode? 7**2")
time.sleep(.5)
print("49")

input("What is the result of the following calculation in Python's interactive mode? (2 + 3) * 5")
time.sleep(.5)
print("25")

input("What arithmetic operators have the highest precedence (parentheses are not operators)?")
time.sleep(.5)
print("**")

input("What would you type at the end of a line if you wanted to continue a Python statement to the next line?")
time.sleep(.5)
print("\\ (backslash)")

input("Write a Python expression that concatenates the string \"My name is \" with the string variable name.")
time.sleep(.5)
print("\"My name is \" + name")

input("Write a Python expression that concatenates the string \"The rate is \"\
with the variable rate which is of type float.")
time.sleep(.5)
print("\"The rate is \" + str(rate)")

input("Write a single print statement, without using triple quotes, which prints \nLine 1 \nLine 2 \nLine 3")
time.sleep(.5)
print("print(\"Line 1\\nLine 2\\nLine 3\")")
