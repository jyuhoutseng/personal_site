import time

print("Quiz_3: ")
input("What are the only values that a boolean expression can have?")
time.sleep(.5)
print("True and False")

input("Write the Python boolean literals.")
time.sleep(.5)
print("True and False")

input("Write the boolean expression that is true if the\
 value of the variable number_1 is greater than or equal to value of the variable number_2.")
time.sleep(.5)
print("number_1 >= number_2")

input("If you typed the following in the Python interactive mode, what would the result be? 5 != 6")
time.sleep(.5)
print("True")

input("Write a Python expression that evaluates to True if the\
 variable whose name is num has a value greater than 0 and less than 10.")
time.sleep(.5)
print("num > 0  and num < 10")

input("What is the data type of the variable whose name is value_good that is created by the following statement?\
 value_good = num > 0")
time.sleep(.5)
print("boolean")

input("If you typed the following in Python's interactive mode, what would the result be? not False")
time.sleep(.5)
print("True")

input("If you typed the following in the Python interactive mode, what would the result be? True and False")
time.sleep(.5)
print("False")

input("If you typed the following in the Python interactive mode, what would the result be? True or False")
time.sleep(.5)
print("True")

input("Write an if/elif/else statement that prints \"Positive\" if the value of the \
variable numb is greater than 0, and prints \"Negative\" if it is less than 0 and print \"Zero\" otherwise.")
time.sleep(.5)
print("if numb > 0:\n    print(\"Positive\") \nelif numb < 0:\n    print(\"Negative\") \nelse:\n    print(\"Zero\")")
