#Quiz Review
import time
import os


def review():
    choose = input("Which quiz would you like to review: ")

    while choose != "end":
        if choose == "1":
            os.startfile(r'"q1.py"')
            review()
        elif choose == "2":
            os.startfile(r'"q2.py"')
            review()
        elif choose == "3":            
            os.startfile(r'"q3.py"')
            review()
        elif choose == "help":
            for quizzes in range(1, 4):
                print(quizzes, end=', ')
            print("end, help, test")
            print()
            review()
        elif choose == "test":
            print()
            review()
        else:
            review()
review()
