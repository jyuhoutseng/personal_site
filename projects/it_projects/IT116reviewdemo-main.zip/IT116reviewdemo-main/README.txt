# IT116reviewdemo

Installation:
Download all the files and put them in the same folder. Run quiz_review.py or just go through them if you want. 
